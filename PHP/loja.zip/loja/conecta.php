<?php
	//$conexao = mysqli_connect('localhost', 'root', '', 'loja');
	$conexao = mysqli_connect('mysql.hostinger.com.br', 'u721272988_loja', 'lojaloja', 'u721272988_loja');