<?php include("cabecalho.php"); ?>
	<?php $nome = "thiago"; ?>
	Loja do <?php echo $nome; ?>
<?php include("rodape.php"); ?>